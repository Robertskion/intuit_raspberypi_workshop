#!/usr/bin/perl

open(FILE, "../filexlist.txt");
chomp(@filelist = (<FILE>));
close(FILE);

foreach $file (@filelist) {
    @filecomps = split("/", $file);
	$filename = $filecomps[-1];
	print $file."\n";
	print $filename."\n";
	system("./extractfaces $file faces/$filename");
}
